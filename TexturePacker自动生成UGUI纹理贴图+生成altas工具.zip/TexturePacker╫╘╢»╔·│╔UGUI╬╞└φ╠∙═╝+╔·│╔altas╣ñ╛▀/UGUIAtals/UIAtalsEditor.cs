﻿using UnityEngine;
using System.Collections;
using UnityEditor;
using System.IO;

public class UIAtalsEditor : Editor
{
    [MenuItem("Tools/CMD/自动创建Plot图集的Atlas")]
    public static void AutoCreateAtlasPrefab()
    {
        string inputPath = PathManager.FileBasePath() + "/_Project/Modules/_Common/GUI/_OutTexture/Plot/";

        string[] files = Directory.GetFiles(inputPath, "*.png", SearchOption.TopDirectoryOnly);

        for (int i = 0; i < files.Length; i++)
        {
            //Debug.Log(files[i]);
            string assetPath = "Assets" + files[i].Substring(Application.dataPath.Length);
            //Debug.Log(assetPath);
            Object assetObj = AssetDatabase.LoadAssetAtPath<Object>(assetPath);
            //Debug.Log(assetObj);
            Selection.activeObject = assetObj;
            CreateAtlasPrefab();
        }

        EditorUtility.DisplayDialog("", "全部生成图片的Atlas结束", "确定");
    }



    [MenuItem("Tools/UGUI/创建当前选中图集的Atlas")]
    public static void CreateAtlasPrefab()
    {
        if (Selection.activeObject != null)
        {
            string path = AssetDatabase.GetAssetPath(Selection.activeObject);
            TextureImporter importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer != null && importer.textureType == TextureImporterType.Sprite && importer.spriteImportMode == SpriteImportMode.Multiple)
            {
                UIAtals atlas = CreateInstance<UIAtals>();
                object[] objs = AssetDatabase.LoadAllAssetsAtPath(path);
                atlas.spriteLists.Clear();
                foreach (object o in objs)
                {
                    if (o.GetType() == typeof(Texture2D))
                    {
                        atlas.mainText = o as Texture2D;
                    }
                    else if (o.GetType() == typeof(Sprite))
                    {
                        atlas.spriteLists.Add(o as Sprite);
                    }
                }

                string[] pathSplit = path.Split('G'); // Modules
                path = pathSplit[0] + "Resources/Atlas/" + Selection.activeObject.name.ToLower() + "_Atlas.prefab";

                Debug.Log(path);

                AssetDatabase.DeleteAsset(path);
                AssetDatabase.Refresh();

                GameObject go = new GameObject("prefab");
                PrefabUtility.SaveAsPrefabAsset(go,path);
                AssetDatabase.Refresh();
                AssetDatabase.AddObjectToAsset(atlas, path);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();

                DestroyImmediate(go);
            }
            else
            {
                EditorUtility.DisplayDialog("", "当前选中的不是图集图片", "确定");
            }
        }
    }
}