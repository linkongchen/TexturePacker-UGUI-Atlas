﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Diagnostics;
using System;
using UnityEditor;
using System.IO;

public class CMDTools : ScriptableObject
{
    [MenuItem("Tools/CMD/自动更新导出协议")]
    public static void CmdProto()
    {
        Process proc = null;
        try
        {
            string targetDir = string.Format(GameSet.CMD_PROTO_PATH);
            proc = new Process();
            proc.StartInfo.WorkingDirectory = targetDir;
            proc.StartInfo.FileName = "GenProto--程序使用.bat";
            proc.StartInfo.Arguments = string.Format("10");
            proc.Start();
            proc.WaitForExit();
            proc.Close();
        }
        catch (Exception ex)
        {
            Console.WriteLine("Exception Occurred :{0},{1}", ex.Message, ex.StackTrace.ToString());
        }
    }



    [MenuItem("Tools/CMD/自动更新导出配置")]
    public static void CmdTable()
    {
        Process proc = null;
        try
        {
            string targetDir = string.Format(GameSet.CMD_XLS_PATH);
            proc = new Process();
            proc.StartInfo.WorkingDirectory = targetDir;
            proc.StartInfo.FileName = "config--程序使用.bat";
            proc.StartInfo.Arguments = string.Format("10");
            proc.Start();
            proc.WaitForExit();
            proc.Close();
        }
        catch (Exception ex)
        {
            Console.WriteLine("Exception Occurred :{0},{1}", ex.Message, ex.StackTrace.ToString());
        }
    }


    [MenuItem("Tools/CMD/自动打包剧情Plot图集")]
    public static void ExecutePackage()
    {
        if (!(Directory.Exists("C:\\Program Files\\CodeAndWeb")
            || Directory.Exists("D:\\Program Files\\CodeAndWeb")
            || Directory.Exists("E:\\Program Files\\CodeAndWeb")
            || Directory.Exists("F:\\Program Files\\CodeAndWeb")
            || Directory.Exists("D:\\Program Files (x86)\\CodeAndWeb")
            || Directory.Exists("F:\\Program Files (x86)\\CodeAndWeb")))
        {
            EditorUtility.DisplayDialog("图集打包",
                     "生成失败" + "\n\n未安装图集打包软件, 如果需要请找骋大侠", "确定");
            return;
        }

        string inputPath = PathManager.FileBasePath() + "/../../../art/人物立绘资源/";
        string outPath = PathManager.FileBasePath() + "/_Project/Modules/_Common/GUI/_OutTexture/Plot/";

        string[] files = Directory.GetDirectories(inputPath, "*", SearchOption.TopDirectoryOnly);

        for(int i =0;i< files.Length;i++)
        {
            //UnityEngine.Debug.Log(files[i]);
            string[] splits = files[i].Split('/');
            string folder_name = splits[splits.Length-1];

            ExecuteOnePackage(inputPath, folder_name, outPath);
        }
    }


    /// <summary>
    /// 调用bat命令打包
    /// </summary>
    /// <param name="dir">图集文件夹路径(打包时需要先cd到该路径), 需要先转换成绝对路径</param>
    /// <param name="folder_name">图集文件夹名字</param>
    /// <param name="atlasPath">打包后图集放到的目标文件夹路径</param>
    /// 
    public static void ExecuteOnePackage(string dir, string folder_name, string atlasPath)
    {
        //参数解析
        //1=>bat命令路径
        //2=>是否弹出cmd窗口
        //3=>bat执行结束回调
        //4.1=>图集文件夹路径(打包时需要先cd到该路径)
        //4.2=>图集文件夹名字
        //4.3=>打包后图集放到的目标文件夹路径
        //4.4=>图集大小限制
        //4.5=>剔除透明方式
        try
        {
            string param1 = dir;
            string param2 = folder_name;
            string param3 = atlasPath;
            string param4 = "1024";
            string param5 = "None";
            string args = param1 + " " + param2 + " " + param3 + " " + param4 + " " + param5;

            //例子
            //string param = "D:/_MySpace/art/人物立绘资源/" + " "
            //                + "banban" + " "
            //                + "D:/_MySpace/client/StardomProject/Assets/_Project/Modules/_Common/GUI/_OutTexture/Plot/" + " "
            //                + "1024" + " "
            //                + "Trim";

            ProcessStartInfo startInfo = new ProcessStartInfo("D:/_MySpace/client/StardomProject/Assets/Editor/CMD/TPackageTool.bat", args);
            Process.Start(startInfo);
        }
        catch (Exception ex)
        {
            Console.WriteLine("Exception Occurred :{0},{1}", ex.Message, ex.StackTrace.ToString());
        }
    }
}
